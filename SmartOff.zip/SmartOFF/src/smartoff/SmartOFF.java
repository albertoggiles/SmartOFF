package smartoff;

import java.io.IOException;
import java.util.Scanner;

public class SmartOFF {
    public static void main(String[] args) throws IOException {
        String comando="";
        int horas;
        Scanner sc=new Scanner(System.in);
        System.out.println("Introduce en horas el temporizador de apagado");
        horas= sc.nextInt();
        int seg=horas*3600;
        if(System.getProperty("os.name").compareTo("Windows 10")==0){
            comando= "shutdown -s -t "+seg; 
        }
        if(System.getProperty("os.name").compareTo("Linux")==0){
            comando= "halt";
        }          
            Runtime.getRuntime().exec(comando);
    }       
}